package com.dku.dogukankarayilanoglu_lab_assignment_12.Controller;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.dku.dogukankarayilanoglu_lab_assignment_12.Database.ItemDatabase;
import com.dku.dogukankarayilanoglu_lab_assignment_12.Modal.Item;
import com.dku.dogukankarayilanoglu_lab_assignment_12.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    public static final String TAG = "MainActivity";
    ArrayList<Item> list = new ArrayList<>();
    ArrayAdapter adapter;
    SwipeMenuListView listView;
    Button addItemButton;
    final ItemDatabase database = new ItemDatabase(this);

    @Override
    protected void onResume() {
        super.onResume();

        list = database.loadItems();
        adapter = new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);




    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
       if(hasFocus){
           //list = database.loadItems();
           updateListView(list);
       }


    }

    public void updateListView(ArrayList<Item> list){
        for(int i=0; i<list.size() ; i++){

            View row = listView.getChildAt(i);

            if(list.get(i).isCompleted() == true){
                row.setBackgroundColor(Color.CYAN);
            }

        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addItemButton = findViewById(R.id.btnAddItem);

        listView = (SwipeMenuListView) findViewById(R.id.swipe_menu_listView);


        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @SuppressLint("Range")
            @Override
            public void create(SwipeMenu menu) {

                SwipeMenuItem completeItem = new SwipeMenuItem(getApplicationContext());
                completeItem.setBackground(new ColorDrawable(Color.rgb(0x0, 0x26,
                        0x255)));
                // set item width
                completeItem.setWidth(170);
                // set item title
                completeItem.setTitle("Change State");
                // set item title fontsize
                completeItem.setTitleSize(18);
                // set item title font color
                completeItem.setTitleColor(Color.WHITE);
                // add to menu
                menu.addMenuItem(completeItem);
                // create "open" item

                SwipeMenuItem updateItem = new SwipeMenuItem(getApplicationContext());
                updateItem.setBackground(new ColorDrawable(Color.rgb(0x0, 0x0,
                        0x0)));
                // set item width
                updateItem.setWidth(170);
                // set item title
                updateItem.setTitle("Update");
                // set item title fontsize
                updateItem.setTitleSize(18);
                // set item title font color
                updateItem.setTitleColor(Color.RED);
                // add to menu
                menu.addMenuItem(updateItem);
                // create "open" item


                SwipeMenuItem openItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                openItem.setBackground(new ColorDrawable(Color.rgb(0xC9, 0xC9,
                        0xCE)));
                // set item width
                openItem.setWidth(170);
                // set item title
                openItem.setTitle("Open");
                // set item title fontsize
                openItem.setTitleSize(18);
                // set item title font color
                openItem.setTitleColor(Color.WHITE);
                // add to menu
                menu.addMenuItem(openItem);


                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9,
                        0x3F, 0x25)));
                // set item width
                deleteItem.setWidth(170);
                // set a icon
                deleteItem.setIcon(R.drawable.ic_delete);
                // add to menu
                menu.addMenuItem(deleteItem);


            }
        };

        listView.setMenuCreator(creator);



        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 2:
                        Intent intent = new Intent(MainActivity.this,ShowItemMapActivity.class);
                        intent.putExtra("index",position);
                        startActivity(intent);
                        break;

                    case 3:

                        Log.d("tagalt", "onMenuItemClick: "+position);

                        database.deleteItem(list.get(position).getId());
                        list=database.loadItems();
                        adapter = new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1,list);

                        listView.setAdapter(adapter);

                        //wait until views are load...
                        listView.post(new Runnable() {
                            @Override
                            public void run() {
                               updateListView(list);
                            }
                        });




                        break;

                    case 1:
                        Intent intentU = new Intent(MainActivity.this,UpdateItemMapActivity.class);
                        intentU.putExtra("index",position);
                        startActivity(intentU);
                        break;

                    case 0:
                        Item item = list.get(position);
                        item.setCompleted(!item.isCompleted());
                        View row = listView.getChildAt(position);

                        if(item.isCompleted() == true){
                            row.setBackgroundColor(Color.CYAN);
                            item.setCompleted(true);
                            database.updateItem(item);
                        }

                        else {
                            row.setBackgroundColor(Color.WHITE);
                            item.setCompleted(false);
                            database.updateItem(item);

                        }

                        break;

                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });


        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddItemMapActivity.class);
                startActivity(intent);
            }
        });
    }
}


