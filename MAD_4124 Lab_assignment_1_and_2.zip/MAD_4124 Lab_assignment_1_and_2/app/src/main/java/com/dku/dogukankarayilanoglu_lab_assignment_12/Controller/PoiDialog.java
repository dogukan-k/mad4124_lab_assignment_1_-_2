package com.dku.dogukankarayilanoglu_lab_assignment_12.Controller;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Switch;

import com.dku.dogukankarayilanoglu_lab_assignment_12.R;

import androidx.appcompat.app.AppCompatDialogFragment;

public class PoiDialog extends AppCompatDialogFragment {

    Switch restaurantSwitch;
    Switch gasStationSwitch;
    Switch schoolSwitch;
    Switch clothingStoreSwitch;

    public boolean restaurantSwitchValue = false;
    public boolean gasStationSwitchValue = false;
    public boolean schoolSwitchValue = false;
    public boolean clothingStoreSwitchValue = false;

    private PoiDialogListener listener;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.poi_layout_dialog,null);

        builder.setView(view)
                .setTitle("Select Point of Interest")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        restaurantSwitchValue = restaurantSwitch.isChecked();
                        gasStationSwitchValue = gasStationSwitch.isChecked();
                        schoolSwitchValue = schoolSwitch.isChecked();
                        clothingStoreSwitchValue = clothingStoreSwitch.isChecked();

                        //Send back data to Add Item Map Activity
                        listener.applyBooleanValues(restaurantSwitchValue,gasStationSwitchValue,schoolSwitchValue,clothingStoreSwitchValue);



                    }
                });

        restaurantSwitch = view.findViewById(R.id.switchRestaurants);
        gasStationSwitch = view.findViewById(R.id.switchGasStations);
        schoolSwitch= view.findViewById(R.id.switchSchools);
        clothingStoreSwitch = view.findViewById(R.id.switchClothingStores);

        restaurantSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(restaurantSwitch.isChecked() == true){
                    gasStationSwitch.setChecked(false);
                    schoolSwitch.setChecked(false);
                    clothingStoreSwitch.setChecked(false);
                }
            }
        });

        gasStationSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(gasStationSwitch.isChecked() == true){
                    restaurantSwitch.setChecked(false);
                    schoolSwitch.setChecked(false);
                    clothingStoreSwitch.setChecked(false);
                }
            }
        });

        schoolSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(schoolSwitch.isChecked() == true){
                    restaurantSwitch.setChecked(false);
                    gasStationSwitch.setChecked(false);
                    clothingStoreSwitch.setChecked(false);
                }
            }
        });

        clothingStoreSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(clothingStoreSwitch.isChecked() == true){
                    restaurantSwitch.setChecked(false);
                    gasStationSwitch.setChecked(false);
                    schoolSwitch.setChecked(false);
                }
            }
        });

        if(restaurantSwitchValue==true){
            restaurantSwitch.setChecked(true);
        }

        if(gasStationSwitchValue==true){
            gasStationSwitch.setChecked(true);
        }

        if(schoolSwitchValue==true){
            schoolSwitch.setChecked(true);
        }

        if(clothingStoreSwitchValue==true){
            clothingStoreSwitch.setChecked(true);
        }


        return builder.create();

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            listener = (PoiDialogListener) context;
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }

    public interface  PoiDialogListener{
        void applyBooleanValues(boolean restaurant , boolean gasStation , boolean school , boolean clothingStore);
    }
}
