package com.dku.dogukankarayilanoglu_lab_assignment_12.Controller;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.dku.dogukankarayilanoglu_lab_assignment_12.Database.ItemDatabase;
import com.dku.dogukankarayilanoglu_lab_assignment_12.Modal.GetDirectionsData;
import com.dku.dogukankarayilanoglu_lab_assignment_12.Modal.Item;
import com.dku.dogukankarayilanoglu_lab_assignment_12.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ShowItemMapActivity extends AppCompatActivity implements OnMapReadyCallback,  AdapterView.OnItemSelectedListener  {

    ArrayList<Item> list = new ArrayList<>();
    Item item;

    MapView mapView;
    private GoogleMap mMap;

    Marker homeMarker;
    Marker destMarker;


    Button btnMyLocation;
    Button btnGetDirection;

    TextView txtDistance;
    TextView txtDuration;

    int resetMyLocation = 0 ;
    boolean locationSelected=false;

    Spinner spinner;
    String destinationAddress="";

    private final int REQUEST_CODE = 1;

    final ItemDatabase database = new ItemDatabase(this);


    //USER LOCATION
    private FusedLocationProviderClient mFusedLocationClient;
    LocationCallback locationCallback;
    LocationRequest locationRequest;

    public final int RADIUS = 1200;
    double latitude ;
    double longitude;

    double dest_lat = 0 ;
    double dest_lng = 0 ;


    int incomingIndex;


    String[] mapTypes = {"Hybrid","Normal","Satellite"};

    Geocoder geocoder;
    List<Address> addresses;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_item_map);

        incomingIndex = getIntent().getExtras().getInt("index");
        list = database.loadItems();
        item = list.get(incomingIndex);


        txtDuration=findViewById(R.id.txtDurationS);
        txtDistance = findViewById(R.id.txtDistanceS);

        geocoder = new Geocoder(this, Locale.getDefault());

        mapView= findViewById(R.id.mapViewS);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        //set spinner
        spinner = findViewById(R.id.mapTypeSpinnerS);
        spinner.setOnItemSelectedListener(this);

        ArrayAdapter mapTypeAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,mapTypes);
        spinner.setAdapter(mapTypeAdapter);


        btnMyLocation = findViewById(R.id.btnMyLocationS);
        btnMyLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetMyLocation = 0;
                getUserLocation();
                if (!checkPermissions())
                    requestPermissions();
                else {
                    mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
                    // If below code not applied , then new instance is not stopable by btnClear again.
                    mFusedLocationClient = mFusedLocationClient;
                }

            }
        });



        btnGetDirection = findViewById(R.id.btnGetDirectionS);
        btnGetDirection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Object[] dataTransfer;
                dataTransfer = new Object[6];
                String url = getDirectionUrl();
                dataTransfer[0] = mMap;
                dataTransfer[1] = url;
                dataTransfer[2] = new LatLng(dest_lat, dest_lng);
                dataTransfer[3] = txtDistance;
                dataTransfer[4] =txtDuration;
                dataTransfer[5] = destinationAddress;

                GetDirectionsData getDirectionsData = new GetDirectionsData();
                // execute asynchronously
                getDirectionsData.execute(dataTransfer);
            }
        });

    }



    @Override
    protected void onResume() {
        mapView.onResume();
        getUserLocation();

        if (!checkPermissions())
            requestPermissions();
        else {
            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
        }
        super.onResume();
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        Location location = new Location("Destination");
        location.setLongitude(Double.parseDouble(item.getLongitude()));
        location.setLatitude(Double.parseDouble(item.getLatitude()));

        dest_lat=(Double.parseDouble(item.getLatitude()));
        dest_lng=(Double.parseDouble(item.getLongitude()));

        setMarker(location);


        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {

                dest_lat = marker.getPosition().latitude;
                dest_lng = marker.getPosition().longitude;
                //to identify if any marker selected
                destinationAddress=marker.getTitle();
                locationSelected=true;
                return false;
            }
        });


        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                //to identify if any marker unselected
                locationSelected=false;

            }
        });


    }

    private void setMarker(Location location) {
        LatLng userLatLng = new LatLng(location.getLatitude(), location.getLongitude());

        MarkerOptions options = new MarkerOptions().position(userLatLng)
                .title(item.getAddress())
                .draggable(false);
        destMarker = mMap.addMarker(options);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        switch (i){
            case 0:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                break;

            case 1:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;

            case 2:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }



    private String getUrl(double latitude, double longitude, String nearbyPlace) {
        StringBuilder googlePlaceUrl = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        googlePlaceUrl.append("location=" + latitude + "," + longitude);
        googlePlaceUrl.append("&radius=" + RADIUS);
        googlePlaceUrl.append("&type=" + nearbyPlace);
        googlePlaceUrl.append("&key=" + getString(R.string.api_key_places));
        Log.d("tagurl", "getUrl: "+googlePlaceUrl);
        return googlePlaceUrl.toString();

    }

    private void setHomeMarker() {

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {


                for (Location location : locationResult.getLocations()) {
                    LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    latitude = userLocation.latitude;
                    longitude = userLocation.longitude;
                    if (homeMarker != null)
                        homeMarker.remove();
//                    mMap.clear(); //clear the old markers

                    CameraPosition cameraPosition = CameraPosition.builder()
                            .target(new LatLng(userLocation.latitude, userLocation.longitude))
                            .zoom(15)
                            .bearing(0)
                            .tilt(45)
                            .build();
                    //run only if resetmylocation values is equal to 0;
                    if(resetMyLocation == 0){

                        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                        resetMyLocation+=1;
                    }

                    String address="";

                    try {
                        addresses = geocoder.getFromLocation(latitude,longitude,1);
                        address = addresses.get(0).getAddressLine(0);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    homeMarker = mMap.addMarker(new MarkerOptions().position(userLocation).title(address)
                            .icon(bitmapDescriptorFromVector(getApplicationContext(), R.drawable.icon_loc)));


                }
            }
        };


    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, @DrawableRes int vectorDrawableResourceId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorDrawableResourceId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setHomeMarker();
                mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

            }
        }
    }

    private boolean checkPermissions() {
        int permissionState = ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        return permissionState == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
    }


    private void getUserLocation() {


        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(3000);

        setHomeMarker();
    }

    private String getDirectionUrl() {
        StringBuilder googleDirectionUrl = new StringBuilder("https://maps.googleapis.com/maps/api/directions/json?");
        googleDirectionUrl.append("origin="+latitude+","+longitude);
        googleDirectionUrl.append("&destination="+dest_lat+","+dest_lng);
        googleDirectionUrl.append("&key="+getString(R.string.api_key_places));
        Log.d("", "getDirectionUrl: "+googleDirectionUrl);
        return googleDirectionUrl.toString();
    }
}
