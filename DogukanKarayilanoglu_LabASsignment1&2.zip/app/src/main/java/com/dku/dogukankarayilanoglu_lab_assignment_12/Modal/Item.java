package com.dku.dogukankarayilanoglu_lab_assignment_12.Modal;

import androidx.annotation.NonNull;

public class Item {

    private int id;
    private String latitude;
    private String longitude;
    private String address;
    private boolean completed;
    private String dateAdded;

    public Item(){

    }

    public Item( String latitude, String longitude, String address, boolean completed, String dateAdded) {

        this.latitude = latitude;
        this.longitude = longitude;
        this.address = address;
        this.completed = completed;
        this.dateAdded = dateAdded;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    @NonNull
    @Override
    public String toString() {
        if(getAddress().equals("")){
            return getDateAdded();
        }
        else {
            return getAddress();
        }

    }
}

